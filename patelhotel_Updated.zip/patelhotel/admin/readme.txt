user side url:-
http://localhost/admin/user/

change connection.php for user side.

add new database,if any error occurs add one by one table