<?php 
  include ('header.php');
  include ('link.html');
  require_once "connection.php" ;
  $conn = connect();
?>

<?php if(isset($_SESSION['id']))
	{ ?>
  <body id="rooms-1__page">
		
    <!-- Info Section
    ================================================== -->
    
  	<!-- Navbar
    ================================================== -->
  

    <!-- CONTENT
      ================================================== -->

    <!-- section home -->
    <section class="section__home" id="section__home">
    	<div class="container">
    		<div class="row">
  	    	<div class="col-sm-12">
  	    		<div class="welcome__content">
							<h1 class="welcome_content__title">Book rooms</h1>
	  					<p class="welcome_content__desc"></p>
		  			</div> <!-- .welcome__content -->
    	    </div>
	    	</div> <!-- / .row -->
    	</div> <!-- / .container -->
			<div class="home__bg"></div>
    </section> <!-- / .section__home -->
    <!-- section rooms-1 -->
    <section class="section__rooms-1">
    	<div class="container">
    	  <?php $rid=intval($_GET['room_id']);
		?>
		<form method="post" action="#">
			<div class="row">
				<div class="col-md-3 form-group"></div></br>
				<div class="col-md-6 form-group">
					<div class="row">
						<div class="col-md-6">
						From Date:
							<input type="date" class="form-control" required="" id="fdate" min="<?php echo date("Y-n-d")?>" max="<?php echo date("Y-n-t",strtotime('today'));?>" name="fdate"></br></br>
						</div>
						<!-------------------Code For SET 'To Date' (Min) value---------------------->
							<script>
								document.getElementById("fdate").onchange=function() {
									var input=document.getElementById("tdate");
									input.value="";
									//input.setAttribute("min", this.value); // type 1
									input.min=this.value;					 // type 2
								}
							</script>
							<!------------------------------------------------------------------------>
						<div class="col-md-6">
						To Date:
							<input type="date" class="form-control" required="" id="tdate" max="<?php echo date("Y-n-t",strtotime('today'));?>" name="tdate"></br></br>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							Room:
							<input type="number" class="form-control" required="" name="room" max="15" min="1"></br></br>
						</div>
						<div class="col-md-4">
							Adult:
							<input type="number" class="form-control" name="adult" required="" max="25" min="1"></br></br>
						</div>
						<div class="col-md-4">
							Children:
							<input type="number" class="form-control" name="child" max="15" min="0"></br></br>
						</div>
					</div>
					<label>Room Type</label>
					<?php 
						$sql="select * from room_info where ri_id='$rid'";
						$result=mysqli_query($conn,$sql);
					?>
					<!--<select class="form-control" name="room_type" required="">-->
					<?php while($r=mysqli_fetch_assoc($result)):?>
					<input type="text" class="form-control" name="room_type" readonly="" value="<?php echo $r['room_type'];?>"></br></br>
					<!--<option><?php //echo $r['room_type'];?></option>-->
					<?php endwhile;?>
					<!--</select></br></br>-->
					<input type="submit" class="form-control " name="book" value="Book Now"></br></br>
				</div>
			<div class="col-md-3"></div></br>
		</div> <!-- .row -->
        </form>
	</div> <!-- / .container -->
    </section> <!-- / .section__rooms-1 -->
	<?php } else 
			{	
				echo "<script>window.location.href='login.php'</script>";
			}
		?>
		
<?php 
include 'footer.html';
?>

  </body>
</html>

<?php 
  if(isset($_POST['book']))
  {
    $fd=$_POST['fdate'];
    $td=$_POST['tdate'];
    $rm=$_POST['room'];
    $a=$_POST['adult'];
    $c=$_POST['child'];
    $rt=$_POST['room_type'];
    $bd=date("Y-n-d");
	$id=$_SESSION['id'];
	
	$sql2="insert into room_book (f_date,t_date,rooms,room_type,adult,child,b_date,id) values('$fd','$td','$rm','$rt','$a','$c','$bd','$id')";
    $result2=mysqli_query($conn,$sql2);
    if($result2)
    {
       echo "<script name='javascript'> alert(' Room Is Book ') </script> ";
	   echo "<script>window.location.href='rooms.php'</script>";
    }
    else
    {
       echo "<script name='javascript'> alert(' Failed ! !') </script> ";
    }
  }
?>