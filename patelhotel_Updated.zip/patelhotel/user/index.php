<?php 
	include ('header.php');
	include ('link.html');
	require "connection.php";
	$conn = connect();
?>

  <body id="index__page">
		
	

 <section class="section__home" id="section__home">
        <div class="container">
            <div class="row">
            <div class="col-sm-12">
                <div class="welcome__content">
                            <h1 class="welcome_content__title">THE PATEL</h1>
                            <p class="welcome_content__title-primary">Hotel and Restaurent</p>
                        <p class="welcome_content__desc">Enjoy your life with us</p>
                        <a href="#section__about" class="btn btn-reservation">Explore it</a>
                    </div> <!-- .welcome__content -->
            </div>
            </div> <!-- / .row -->
        </div> <!-- / .container -->
            <div class="home__bg"></div>
    </section> <!-- / .section__home -->

		<!-- Info Section
    ================================================== -->
		
	   
	<!-- section about -->
    <section class="section__about" id="section__about">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12"> 		  	
    				<h2 class="section__title">Welcome to <strong>The Patel Hotel</strong></h2>
    				<div class="divider">
    					<hr class="line1">
    					<hr class="line2">
    					<hr class="line1">
    				</div> <!-- / .divider -->
    			</div>
    		</div> <!-- / .row -->
    	</div> <!-- / .container -->
    	<div class="container-fluid">
    		<div class="row">
		    	<div class="section_about__content">
		    	  <div class="col-md-6">
		    	  	<div class="about__pic">
		    				<img src="assets/img/about_img.jpg" class="img-responsive" alt="...">
		    			</div> <!-- / .about__pic -->
		    	  </div>
		    	  <div class="col-md-6">
			    	  <div class="about__desc">
			    	  	<p class="about_desc__subtitle">About us</p>
			  				<h3 class="about_desc__title">Probably the best place to enjoy your life</h3>
								<p class="about_desc__desc">At The Patel hotel , our passion is to connect our guest to the very best of our destination. From the foot hills of Girnar to the heritage Bhavnath Mahadev Temple.


Our hotel offers guests extraordinary places created by combining unique architecture and structure. At great service, and the result is an unforgetable guest experience.<br>


While we aim to give you an authentic experience of the local whenever you stay with us, we also guarentee consistant high standard throughout our collection of hotel.</p>
								
							
			  			</div> <!-- / .about__desc -->
		    	  </div>
		    	</div> <!-- / .section_about__content -->
		    </div> <!-- / .row -->
    	</div>
	    
    </section> <!-- / .section__about -->
		
		<!-- section best-rooms -->
    <section class="section__best-rooms">
    	<div class="container">
    		<div class="row">
    		  <div class="col-sm-12"> 		  	
    				<h2 class="section__title">Our <strong>Best Rooms</strong></h2>
    				<div class="divider">
    					<hr class="line1">
    					<hr class="line2">
    					<hr class="line1">
    				</div> <!-- / .divider -->
    				<p class="section__subtitle">

    					The Patel hotel Maldives is a masterpiece of simplicity, comfort and elegance, offering the ultimate in luxury, with the most spacious rooms among maldives hotels.

    				</p>
    		  </div>
    		</div> <!-- / .row -->
    	</div> <!-- / .container -->
    	<div class="container">
    		<div class="best-rooms__content">
		    	<div class="row">
		    	  <div class="col-sm-6">
		    	  	<figure class="best-rooms__item">
	    	  			<img src="assets/img/single bed.jpeg" class="img-responsive" alt="...">
								<figcaption>
									<h3>Single Bed Room</h3>
									
									<p class="item__desc">At The Patel Hotels all 19 rooms offering maximum facilities as per needs and feels more comfortable.</p>
									
								</figcaption>
							</figure> <!-- / .best-rooms__item -->
		    	  </div>
		    	  <div class="col-sm-6">
		    	  	<figure class="best-rooms__item">
								<img src="assets/img/double bed.jpeg" class="img-responsive" alt="...">
								<figcaption>
									<h3>Double Bed Room</h3>
									
									<p class="item__desc">At The Patel Hotels all 19 rooms offering maximum facilities as per needs and feels more comfortable.</p>
									
								</figcaption>
							</figure> <!-- / .best-rooms__item -->
		    	  </div>
		    	</div> <!-- / .row -->
		    	<div class="row">
		    	  <div class="col-sm-6">
		    	  	<figure class="best-rooms__item">
								<img src="assets/img/luxuries.jpeg" class="img-responsive" alt="...">
								<figcaption>
									<h3>Luxuries Room</h3>
									
									<p class="item__desc">At The Patel Hotels all 19 rooms offering maximum facilities as per needs and feels more comfortable.</p>
									
								</figcaption>
							</figure> <!-- / .best-rooms__item -->
		    	  </div>
		    	  <div class="col-sm-6">
			    	  <figure class="best-rooms__item">
								<img src="assets/img/room-3.jpg" class="img-responsive" alt="...">
								<figcaption>
									<h3>Our Special Room</h3>
									
									<p class="item__desc">At The Patel Hotels all 19 rooms offering maximum facilities as per needs and feels more comfortable.</p>
								<!-- <a href="reservation.html" class="btn-book">Book now <i class="icon ion-chevron-right"></i><i class="icon ion-chevron-right"></i></a> -->
								</figcaption>
							</figure> <!-- / .best-rooms__item -->
		    	  </div>
		    	</div> <!-- / .row -->
		    </div> <!-- / .best-rooms__content -->
	    </div> <!-- / .container -->
    </section> <!-- / .section__best-rooms -->

    <!-- section services -->
    <section class="section__services">
    	<div class="container-fluid">
		    <div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="services__item">
							<h2 class="services_item__title">Parking</h2>
							<div class="services_item__divider">
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
							</div> <!-- .services_item__divider -->
							<p class="services_item__desc">Amazing large parking to for all the vehicals easily. alternate car parking with high end security makes your vehicles safe and secured.</p>
						</div> <!-- .services__item -->
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="services__item">
							<h2 class="services_item__title">Fitness Hall</h2>
							<div class="services_item__divider">
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
							</div> <!-- .services_item__divider -->
							<p class="services_item__desc">Keeping up with your fitness regime during your holiday is simple at our Fitness. Discover a state-of-the-art fitness centre that is the only one of its kind in maldives.</p>
						</div> <!-- .services__item -->
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="services__item">
							<h2 class="services_item__title">Restaurant</h2>
							<div class="services_item__divider">
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
							</div> <!-- .services_item__divider -->
							<p class="services_item__desc">We are proud to present a wealth of options when it comes to fine Asian Dining, including the world famous Nobu known for it's amazing Sushi and Japanese Cuisine. nominated the 2015 best Asian restaurant in maldives .</p>
						</div> <!-- .services__item -->
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="services__item">
							<h2 class="services_item__title">Event Hall</h2>
							<div class="services_item__divider">
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
								<i class="icon ion-android-star"></i>
							</div> <!-- .services_item__divider -->
							<p class="services_item__desc">With a huge variety of boardrooms, conference halls and outdoor venues to choose from, the location and theme for your next function is limited only by your imagination.</p>
						</div> <!-- .services__item -->
					</div>
		    </div> <!-- / .row -->
	    </div> <!-- / .container -->
    </section> <!-- / .section__services -->

    <!-- section gallery -->
    <section class="section__gallery">
    	<div class="container">
    		<div class="row">
    		  <div class="col-sm-12"> 		  	
    				<h2 class="section__title">Our <strong>Gallery</strong></h2>
    				<div class="divider">
    					<hr class="line1">
    					<hr class="line2">
    					<hr class="line1">
    				</div> <!-- / .divider -->
    				<p class="section__subtitle">A landmark of both culture and comfort, in the glorious Maldives, the hotel has an enviable location in the heart of all business and shopping areas, - only 21 km away from the Beach.</p>
    		  </div>
    		</div> <!-- / .row -->
    	</div> <!-- / .container -->
    	<div class="container-fluid">
		    <div class="row">
		    	<div class="col-xs-12">
		    		<div id="gallery__carousel" class="owl-carousel owl-theme gallery__body">
		    			<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img1.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img1.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img2.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img2.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img3.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img3.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img4.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img4.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img5.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img5.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img6.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img6.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img7.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img7.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img8.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img8.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img9.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img9.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img10.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img10.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img11.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img11.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
	            <div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img12.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img12.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img13.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img13.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img14.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img14.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img15.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img15.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img16.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img16.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img17.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img17.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img18.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img18.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
				<div class="gallery__item">
	              <a href="assets/img/gimg/gallery_img19.jpg" data-lightbox="gallery" data-title="Your caption">
	                <img src="assets/img/gimg/gallery_img19.jpg" class="img-responsive" alt="...">
	              </a>
	            </div> <!-- .gallery__item -->
		    		</div> <!-- .gallery__body -->
		    	</div>
		    </div> <!-- / .row -->
	    </div> <!-- / .container -->
    </section> <!-- / .section__gallery -->

	<!-- section Contacts -->
    <section class="section__contacts">
    	<div class="container">
    		<div class="row">
    		  <div class="col-sm-12"> 		  	
    				<h2 class="section__title"><strong>Contact</strong> us</h2>
    				<div class="divider">
    					<hr class="line1">
    					<hr class="line2">
    					<hr class="line1">
    				</div> <!-- / .divider -->
    		  </div>
    		</div> <!-- / .row -->
    	</div> <!-- / .container -->
      <div class="section_row">
       <!-- Map -->
		 <div class="section_row">
       <!-- <div id="map"></div>-->
	   <img src="assets/img/slide_bg_1.jpg" class="img-responsive"  height="20px"></img>
      </div> 
		
	   </div> <!-- / .section_row -->
      <div class="container">
      	<div class="row">
	        <div class="col-sm-5">
						<div class="contacts__info">
							<p class="contacts_info__title">Information</p>
							<ul class="contacts_info__content">
	              <li>
	                <i class="icon ion-android-pin"></i>
	                <div class="contact-info-content">
	                  <div class="title">Address</div>
	                  <div class="description">The Patel Hotel & Restaurant , Maldives - 362004.

</div>
	                </div>
	              </li>
	              <li>
	                <i class="icon ion-android-call"></i>
	                <div class="contact-info-content">
	                  <div class="title">Phone / Inquiry</div>
	                  <div class="description">0220 2222220 </div>
	                </div>
	              </li>
	              <li>
	                <i class="icon ion-android-mail"></i>
	                <div class="contact-info-content">
	                  <div class="title">E-mail</div>
	                  <div class="description">thepatelhotel@gmail.com</div>
	                </div>
	              </li>
	            </ul> <!-- .contacts_info__content -->
						</div> <!-- / .contacts__info -->
						<p class="subheading">If you have any questions don't hesistate to contact us.</p>
	        </div>
	        <div class="col-sm-7">
	        	<div class="section-contacts__form_body">
              

              <!-- Alert message -->
              <div class="alert" id="form_message" role="alert"></div>
							
							<p class="section-contacts__title">Get in touch</p>

              <!-- Please carefully read the README file in order to setup the PHP contact form properly -->
              <form id="form_sendemail" class="contacts__form" method="post">
                <div class="form-group">
                  <label for="email">Email address (Required)</label>
                  <input type="email" name="email" class="form-control" id="email" placeholder="Enter Your E-mail" required="" maxlength="30">
                  <span class="help-block"></span>
                </div>

                <div class="form-group">
                  <label for="name">Name  (Required)</label>
                  <input type="text" name="name" class="form-control" id="name" placeholder="Enter Your Full Name" maxlength="15" required="" pattern="[A-Za-z]{1,15}$" title="Allow Only Character">
                  <span class="help-block"></span>
                </div>

                <div class="form-group">
                  <label for="message">Message  (Required)</label>
                  <textarea name="message" class="form-control" rows="6" id="message" placeholder="Enter Your Message" required="" maxlength="150"></textarea>
                  <span class="help-block"></span>
                </div>
              
                <div class="btn-group">
                  <button type="submit" name="send" class="btn">
                    Send Message
                  </button>
                </div>
              </form> <!-- .contacts__form -->
            </div> <!-- / .secction-contacts__form_body -->
	        </div>
	      </div> <!-- / .row -->
      </div> <!-- / .container -->
    </section> <!-- / .section__contacts -->

		<!-- section footer -->
    <?php 

    include 'footer.html';
    ?>
    <!-- 
    ================================================== -->

    <!-- JS Global -->
   

  </body>

</html>
<!----------------------------------Add Contact Us in Admin Database-------------------------->
<?php
	if(isset($_POST['send']))
	{
		$n=$_POST['name'];
		$e=$_POST['email'];
		$m=$_POST['message'];
		
		$sql="insert into contact(name,email,message) values('$n','$e','$m')";
		$result=mysqli_query($conn,$sql);
		if($result)
		{
			//$msg='Your Message Is Send Waiting For Reply';
			echo "<script>alert('Your Message Is Send Waiting For Reply')</script>";
		}
		else
		{
			echo "<script>alert('Your Message Is NOT Send')</script>";
		}
		//echo "<script>alert('Your Message Is NOT Send')</script>";
	}
?>
<!-------------------------------------------------------------------------------------------->