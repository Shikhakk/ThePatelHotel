<?php  
	include "header.php";   
	require "connection.php";// database connection
	include "link.html";
	
	if(isset($_SESSION['id']))
	{	
		$id=$_SESSION['id'];
	}
	else
		echo "<script>window.location.href='login.php'</script>";
	
	$conn = connect();
	//already created common templates 
?>
<body id="rooms-1__page">
<script>
	function addnew()
	{
var dynamiclist = document.getElementById("dynamic_list");

var content="<div class='row'><div class='col-md-4'>";
content+= "<select class='form-control' name='item_id[]' required=''>"+dynamiclist.innerHTML+"</select></br></br>"
+"							</div>"
+"							<div class='col-md-4'>"
+"								<input type='number' max='10' min='1' required='' class='form-control' name='item_qty[]' placeholder='qty'></br></br>"
+"							</div>"
+"						</div>";
var mainDiv = document.getElementById("dynamicrow");

mainDiv.innerHTML += content;

	}
</script>
	<!-- Info Section
    ================================================== -->
    
  	<!-- Navbar
    ================================================== -->
  

    <!-- CONTENT
      ================================================== -->
        <section>
		<div class="container">
    		<div class="row">
			<div class="col-lg-12">
			<div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div>
								<h2 class="card-title">Order Food</h2>
                        </div>
					</div>
                </div>
				<form method="post" action="">
				<div class="container">
					<div class="row">
					<?php 
						$ts="select * from reg where id='$id'";
						$tr=mysqli_query($conn,$ts);
						while($rtr=mysqli_fetch_assoc($tr))
						{
					?>
						<div class="col-md-4">
							Name:
							<input type="text" class="form-control" readonly="" value="<?php echo $rtr['fname'];?>" name="fname"></br></br>
						</div>
						<div class="col-md-4">
							Phone:
							<input type="text" class="form-control" readonly="" value="<?php echo $rtr['mob'];?>" name="mob" ></br></br>
						</div>
					<?php  
						} ?>
						<div class="col-md-4">
							Room Number
					<?php 
								$sql="select * from book_no where id='$id' and cin!='0000-00-00 00:00:00' and cout='0000-00-00 00:00:00'";
								$result=mysqli_query($conn,$sql);
					?>
								<select class="form-control" name="room_no" required="">
								<?php while($r=mysqli_fetch_assoc($result)):?>
									<option value="<?php echo $r['room_no'];?>"><?php echo $r['room_no'];?></option>
								<?php endwhile;?>
								</select><br><br>
						</div>
					</div>
					<label for="">Item List</label></br>
						<div class="row" id="addnew">
							<div class="col-md-4">
								<?php 
									$sql1="select * from item_info order by iname";
									$result1=mysqli_query($conn,$sql1);
								?>
								<select class="form-control" name="item_id[]" required="" id="dynamic_list">
								<?php while($r1=mysqli_fetch_assoc($result1)):?>
									<option value="<?php echo $r1['ii_id']?>"><?php echo $r1['iname'];?></option>
								<?php endwhile;?>
								</select></br></br>
							</div>
							<div class="col-md-4">
								<input type="number" max="10" min="1" class="form-control" required="" name="item_qty[]" placeholder="qty"></br></br>
							</div>
							<div class="col-md-4">
								<input type="button" name="new" class="form-control" value="Add New" onclick="addnew()"></br></br>
							</div>
						</div>

						<div id="dynamicrow">


						</div>

						<label for="">Custom Order</label>
						<textarea name="custom" maxlength="300" class="form-control" rows="5"></textarea><br>
						<input type="submit" class="form-control " name="order" value="Book Now"></br></br>
				</div>
				</form>
				</div>
				</div>
			</div>
		</div>
		</section>
        
<!-- ============================================================== -->
<!-- ending coding-->
<?php
	require "footer.html";
?>	
</body>
</html> 
<!--------------- Starting PHP Coding For Insert Room Data In Database ----------------------------->
<?php 
	if(isset($_POST['order']))
	{
		$rn=$_POST['room_no'];
		$c=$_POST['custom'];
		$item_id= implode(",",$_POST['item_id']);
		$item_qty = implode(",",$_POST['item_qty']);
		$od=date("Y-n-d");
			//---------------------------------------------------------------------
			 
										/*	  $item = explode(',',$item_id);
													foreach ($item as $i) {
														if ($i !== '') {
																$qty = explode(',',$item_qty);
																foreach ($qty as $q){
																	$sum= array();
																	$isn="select price from item_info where ii_id='$i'";
																	$risn=mysqli_query($conn,$isn);
																	while($ri=mysqli_fetch_assoc($risn))
																	{
																		$sum[]=$ri['price'] * $q;
																	}
																	$s1=implode('/', $sum);
																}
																//echo print_r($sum);
																$s2=$s1."/";
																echo $s2;
																//echo array_sum($sum);
														}
													}*/
											
			//----------------------------------------------------------------------
		
		$fs="select * from book_no where room_no='$rn' and id='$id' and cin!='0000-00-00 00:00:00' and cout='0000-00-00 00:00:00'";
		$rfs=mysqli_query($conn,$fs);
		if(mysqli_num_rows($rfs)==1)
		{
			while($rrfs=mysqli_fetch_assoc($rfs))
			{
				$bnid=$rrfs['bn_id'];
			}
			$ins="insert into order_item(bn_id,ii_id,qty,custom,room_no,odate,price)values('$bnid','$item_id','$item_qty','$c','$rn','$od','')";
			$rins=mysqli_query($conn,$ins);
			if($rins)
			{
				echo "<script>alert('Your Order Is Booked Plz Wait For Delivery')</script>";
				echo '<script> window.location.href="order_menu.php" </script>';
			}
			else
			{
				echo "<script>alert('Failed')</script>";
			}
		}
	} 
?>
<!--------------- ==================================================== ----------------------------->

