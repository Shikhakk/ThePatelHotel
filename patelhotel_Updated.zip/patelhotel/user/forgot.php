
<?php 
  include ('header.php');
  include ('link.html');
  require('connection.php');
  $conn = connect();
?>

<body id="rooms-1__page" class="skin-default card-no-border">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">THE PATEL HOTEL</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <section id="wrapper">
        <div class="login-register">
            <div class="login-box card">
                <div class="card-body">
                    <form class="form-horizontal form-material" id="loginform" action="#" method="post">
                        <h3 class="text-center m-b-20">Forgot Password</h3>
                        <div class="form-group ">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6">
                                <input class="form-control" type="email" maxlength="30" required="" name="email" placeholder="Email Id">
							</div>
							<div class="col-xs-3"></div>
						</div>
                        <div class="form-group">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6">
                               <label style="color:blue">Select Your Security Question</label></br>
									<select class="form-control" required="" name="seq_qus">
										<option >What is your Dream ?</option>
										<option >Where are you Live ?</option>
										<option >What is your Favorite ?</option>
										<option >What is your Hobby ?</option>
									</select></div>
							<div class="col-xs-3"></div>
                        </div>
						<div class="form-group">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6">
                                <input class="form-control" type="password" maxlength="20" required="" name="seq_ans" pattern="[A-Za-z]{1,20}$" title="Allow Only Character" placeholder="Enter Security Answer"> 
							</div>
							<div class="col-xs-3"></div>
                        </div>
						<div class="form-group">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6">
							 <label style="color:blue">New Password</label></br>
                                <input class="form-control" type="password" maxlength="10" required="" name="pass" placeholder="Enter New Password"> 
							</div>
							<div class="col-xs-3"></div>
                        </div>
                        <div class="form-group text-center">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6 p-b-20">
                                <button class="btn bg-success" name="update" type="submit">Update</button>
                            </div>
							<div class="col-xs-3"></div>
                        </div>
					</form>
                </div>
            </div>
        </div>
    </section>
    <?php 
include 'footer.html';
?>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
 
    <!--Custom JavaScript -->
    <script type="text/javascript">
        $(function() {
            $(".preloader").fadeOut();
        });
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });
        // ============================================================== 
        // Login and Recover Password 
        // ============================================================== 
        $('#to-recover').on("click", function() {
            $("#loginform").slideUp();
            $("#recoverform").fadeIn();
        });
    </script>    
</body>
</html>
<?php
	
	if(isset($_POST['update']))
	{
		$e=$_POST['email'];
		$sq=$_POST['seq_qus'];
		$sa=$_POST['seq_ans'];
		$p=$_POST['pass'];
	
		$sql="select * from reg where email='$e' ";
		$result=mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result)==1)
		{
			$up="update reg set password='$p' where email='$e' and seq_qus='$sq' and seq_ans='$sa'";
			$rup=mysqli_query($conn,$up);
			if($rup)
			{
				echo "<script name='javascript'> alert('Your New Password Updated')</script> ";
				echo '<script> window.location="login.php" </script>';
			}
			else
				echo "<script name='javascript'> alert('Update Failed')</script> ";
		}
		else
		{
			echo "<script name='javascript'> alert('Check Your Email Id')</script> ";
		}
	}
?>