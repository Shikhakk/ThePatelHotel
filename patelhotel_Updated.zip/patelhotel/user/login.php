
<?php 
  include ('header.php');
  include ('link.html');
  require('connection.php');
  $conn = connect();
?>

<body id="rooms-1__page" class="skin-default card-no-border">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">THE PATEL HOTEL</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <section id="wrapper">
        <div class="login-register">
            <div class="login-box card">
                <div class="card-body">
                    <form class="form-horizontal form-material" id="loginform" action="#" method="post">
                        <h3 class="text-center m-b-20">Sign In</h3>
                        <div class="form-group ">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6">
                                <input class="form-control" type="email" maxlength="30" required="" name="email" placeholder="Email Id">
							</div>
							<div class="col-xs-3"></div>
						</div>
                        <div class="form-group">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6">
                                <input class="form-control" type="password" maxlength="10" required="" name="pass" placeholder="Password"> 
							</div>
							<div class="col-xs-3"></div>
                        </div>
                        <div class="form-group row">
							<div class="col-xs-3"></div>
                            <div class="col-md-6">
                                <div class="d-flex no-block align-items-center">
                                    <div class="ml-auto">
                                        <a href="forgot.php" class="text-muted"><i class="fas fa-lock m-r-5"></i> Forgot pwd?</a> 
                                    </div>
                                </div>
							</div>
							<div class="col-xs-3"></div>
                        </div>
                        <div class="form-group text-center">
							<div class="col-xs-3"></div>
                            <div class="col-xs-6 p-b-20">
                                <button class="btn bg-success" name="login" type="submit">Log In</button>
                            </div>
							<div class="col-xs-3"></div>
                        </div>
						<div class="form-group row">
							<div class="col-xs-3"></div>
                            <div class="col-md-6 text-center">
                                <div class="d-flex no-block align-items-center">
                                    <div class="ml-auto">
                                      Don't Have an Account ? <a href="register.php" style="color:blue" class="text-muted"><i class="fas fa-lock m-r-5"></i>Register</a> 
                                    </div>
                                </div>
							</div>
							<div class="col-xs-3"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php 
include 'footer.html';
?>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
 
    <!--Custom JavaScript -->
    <script type="text/javascript">
        $(function() {
            $(".preloader").fadeOut();
        });
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });
        // ============================================================== 
        // Login and Recover Password 
        // ============================================================== 
        $('#to-recover').on("click", function() {
            $("#loginform").slideUp();
            $("#recoverform").fadeIn();
        });
    </script>    
</body>
</html>
<?php
	
	if(isset($_POST['login']))
	{
		$e=$_POST['email'];
		$p=$_POST['pass'];
	
		$sql="select * from reg where email='$e' and password='$p' ";
		$result=mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result)==1)
		{
			while($r=mysqli_fetch_row($result))
			{
				$_SESSION['id']=$r[0];
				//$_SESSION['email']=$r[1];
				$_SESSION['lgname']=$r[1];
			}
			//echo "<script name='javascript'> alert('Hello Admin') </script> ";
			echo '<script> window.location="index.php" </script>';
		}
		else
		{
			echo "<script name='javascript'> alert('Check Your Email Id/Password') </script> ";
		}
	}
?>