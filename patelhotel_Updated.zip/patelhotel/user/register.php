<?php 
  include ('header.php');
  include ('link.html');
     require_once "connection.php" ;
  $conn = connect();
?>

  <body id="rooms-1__page">
		
    <!-- Info Section
    ================================================== -->
    
  	<!-- Navbar
    ================================================== -->
  

    <!-- CONTENT
      ================================================== -->

    <!-- section home -->
    <section class="section__home" id="section__home">
    	<div class="container">
    		<div class="row">
  	    	<div class="col-sm-12">
  	    		<div class="welcome__content">
							<h1 class="welcome_content__title">Book rooms</h1>
	  					<p class="welcome_content__desc"></p>
		  			</div> <!-- .welcome__content -->
    	    </div>
	    	</div> <!-- / .row -->
    	</div> <!-- / .container -->
			<div class="home__bg"></div>
    </section> <!-- / .section__home -->

    <!-- section rooms-1 -->
    <section class="section__rooms-1">
    	<div class="container">
    		<div class="row">
  <div class="login-box card">
            <div class="card-body">
                <form class="form-horizontal form-material" id="loginform" action="#" method="post">
                    <!--<div class="text-center">
                        <a href="javascript:void(0)" class="db"><img src="assets/images/logo-icon.png" alt="Home" /><br/><img src="assets/images/logo-text.png" alt="Home" /></a>
                    </div>-->
                    <h3 class="box-title m-t-40 m-b-0">Register Now</h3><small>Create your account</small>
        			<div class="form-group m-t-20">
                        <div class="col-xs-6">
                            <input class="form-control" type="text" required="" maxlength="15" name="fname" placeholder="First Name">
                        </div>
						<div class="col-xs-6">
                            <input class="form-control" type="text" required="" maxlength="15" name="lname" placeholder="Last Name">
                        </div>
                    </div>
					<div class="form-group m-t-20">
                        <div class="col-xs-6">
                            <input class="form-control" type="text" required="" maxlength="15" name="city" placeholder="City">
                        </div>
						<div class="col-xs-6">
                            <input class="form-control" type="text" required="" maxlength="10" name="mob" placeholder="Mobile Number">
                        </div>
                    </div>
                    <div class="form-group ">
                        <div class="col-xs-12">
                            <input class="form-control" type="email" required="" maxlength="30" name="email1" placeholder="Email">
                        </div>
                    </div>
                    <div class="form-group ">
                        <div class="col-xs-12">
                            <input class="form-control" type="password" required="" maxlength="10" name="password1" placeholder="Password">
                        </div>
                    </div>
					<div class="form-group ">
						<div class="col-xs-12">
							<label style="color:blue">Select Your Security Question</label></br>
							<select class="form-control" required="" name="seq_qus">
								<option >What is your Dream ?</option>
								<option >Where are you Live ?</option>
								<option >What is your Favorite ?</option>
								<option >What is your Hobby ?</option>
							</select>
						</div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" type="password" name="seq_ans" maxlength="20" required="" placeholder="Enter Security Answer"> 
						</div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-12">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" name="check" id="customCheck1">
                                <label class="custom-control-label" for="customCheck1">I agree to all <a href="javascript:void(0)">Terms</a></label> 
                            </div> 
                        </div>
                    </div>
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" id="sn" name="signup" type="submit">Sign Up</button>
                        </div>
                    </div>
				    <div class="form-group m-b-0">
                        <div class="col-sm-12 text-center">
                            <p>Already have an account? <a href="login.php" class="text-info m-l-5"><b>Sign In</b></a></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>


        </div> <!-- .row -->
       



	    </div> <!-- / .container -->
    </section> <!-- / .section__rooms-1 -->

		
<?php 
include 'footer.html';
?>

  </body>

<?php
	

	if(isset($_POST['signup']))
	{
		if(isset($_POST['check']))
		{
			$f=$_POST['fname'];
			$l=$_POST['lname'];
			$c=$_POST['city'];
			$m=$_POST['mob'];
			$e=$_POST['email1'];
			$p=$_POST['password1'];
			$sq=$_POST['seq_qus'];
			$sa=$_POST['seq_ans'];
			
			$sql1="select * from reg where email='".$e."' ";
			$result1=mysqli_query($conn,$sql1);
			if(mysqli_num_rows($result1)==1)
			{
				echo "<script name='javascript'> alert('This Email Address Already Used') </script> ";
			}
			else
			{
				$sql="INSERT INTO reg (fname,lname,city,mob,email,password,seq_qus,seq_ans) VALUES ('$f','$l','$c','$m','$e','$p','$sq','$sa')";
				if(mysqli_query($conn,$sql))
				{
					echo "<script name='javascript'> alert('Registration Succeeded !!') </script> ";
					//header('Location: pages-login.php');
					echo '<script> window.location="login.php" </script>';
				}
				else
				{
					echo "<script name='javascript'> alert('Registration Failed !') </script> ";
				}
			}
		}
		else
			echo "<script name='javascript'> alert('click allow option !') </script> ";
	}
?>
</html>